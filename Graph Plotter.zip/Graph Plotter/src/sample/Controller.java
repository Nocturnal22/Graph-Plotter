package sample;
import javafx.animation.PathTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.util.Duration;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;


import javafx.scene.text.Font;

import javafx.util.Pair;

import java.io.*;
import java.net.URL;
import java.util.*;
import java.util.ArrayList;
class MyClass{
    int w;
    Edges obj;
    void add_here(Edges obj, int w){
        this.w=w;
        this.obj=obj;
    }
    String get_to(){
        return this.obj.get_name();
    }
    void set_x(int x){
        this.obj.set_x(x);
    }
    void set_y(int y){
        this.obj.set_y(y);
    }
    int get_x(){
        return this.obj.get_x();
    }
    int get_y(){
        return this.obj.get_y();
    }
    int get_w(){
        return this.w;
    }
    void set_w(int w){
        this.w=w;
    }
}
class Edges{
    private String name;
    private int x,y;
    ArrayList<MyClass> object = new ArrayList<MyClass>();
    Edges(String name,int x,int y){
        this.name=name;
        this.x=x;
        this.y=y;
    }
    String get_name(){
        return name;
    }
    int get_x(){
        return x;
    }
    int get_y(){
        return y;
    }
    void set_x(int i){
        this.x=i;
    }
    void set_y(int j){
        this.y=j;
    }
    int add_edge(String to, int w, ArrayList<Edges> list){
        int flag=0;
        for(int i=0;i<object.size();i++){
            if(object.get(i).get_to().equals(to))
                return 0;
        }
        for(int i=0;i<list.size();i++){
            String name2 = list.get(i).get_name();
            if(name2.equals(to)){
                this.object.add(new MyClass());
                this.object.get(object.size()-1).add_here(list.get(i),w);
                flag=1;
                break;
            }
        }
        return flag;
    }
    void sort(){
        Collections.sort(object , new Compare2() );
    }
}
public class Controller implements Initializable{
    ArrayList<Edges> list = new ArrayList<Edges>();
    int gl = 8;
    GridPane gridPane = new GridPane();
    @FXML
    ToggleButton vertex_mode,edge_mode;
    @FXML
    TextField name,x_coord,y_coord,name2,name3,name4,new_x,new_y,from,to,weight,from2,to2,from3,to3,from4,to4,new_w,from5,to5,file_txt,fileout_txt,type;
    @FXML
    Button add,search,delete,modify,add_edge,search_edge,delete_v,clearing;
    @FXML
    TextArea output;
    @FXML
    private AnchorPane root;
    @FXML
    private GridPane gridPaneMain;
    public void add_vertex(ActionEvent e){
        try {
            String name1 = name.getText();
            String x1 = x_coord.getText();
            String y1 = y_coord.getText();
            if(name1.length()==0||x1.length()==0||y1.length()==0)
            {
                throw new Exception();
            }
            name.clear();
            x_coord.clear();
            y_coord.clear();
            int i = Integer.parseInt(y1);
            int j = Integer.parseInt(x1);
            Edges obj = new Edges(name1, i, j);
            int flag=0;
            for(int i1=0;i1<list.size();i1++){
                if(list.get(i1).get_name().equals(name1))
                    throw new Exception();
            }
            list.add(obj);
            output.setText(name1 + " vertex added successfully at " + x1 + "," + y1);
            clear_all();
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void show_vertex(ActionEvent e){
        try {
            String name1 = name2.getText();
            if(name1.length()==0)
                throw new Exception();
            name2.clear();
            int flag=0;
            for (int i = 0; i < list.size(); i++) {
                String name = list.get(i).get_name();
                if (name.equals(name1)) {
                    output.setText("vertex " + name + " has coordinates" + Integer.toString(list.get(i).get_x()) + "," + Integer.toString(list.get(i).get_y()));
                    flag=1;
                    break;
                }
            }
            if(flag==0)
                throw new Exception();
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Enter Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void delete_vertex(ActionEvent e){
        try {
            String name1 = name3.getText();
            if(name1.length()==0)
                throw new Exception();
            name3.clear();
            int flag=0;
            for (int i = 0; i < list.size(); i++) {
                String name = list.get(i).get_name();
                if (name.equals(name1)) {
                    list.remove(i);
                    output.setText("vertex " + name + " removed successfully");
                    flag=1;
                    break;
                }
            }
            if(flag==0)
                throw new Exception();
            for (int i = 0; i < list.size(); i++) {
                for (int j = 0; j < list.get(i).object.size(); j++) {
                    String name = list.get(i).object.get(j).get_to();
                    if (name.equals(name1)) {
                        list.get(i).object.remove(j);
                        break;
                    }
                }
            }
            clear_all();
        }
        catch(Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void modify_vertex(ActionEvent e){
        try {
            String name1 = name4.getText();
            String x1 = new_x.getText();
            String y1 = new_y.getText();
            if(name1.length()==0||x1.length()==0||y1.length()==0)
                throw new Exception();
            name4.clear();
            new_x.clear();
            new_y.clear();
            int flag=0;
            int i1 = Integer.parseInt(x1);
            int j1 = Integer.parseInt(y1);
            for (int i = 0; i < list.size(); i++) {
                String name = list.get(i).get_name();
                if (name.equals(name1)) {
                    list.get(i).set_x(i1);
                    list.get(i).set_y(j1);
                    output.setText("vertex " + name + " changed successfully : new coordinates: " + x1 + "," + y1);
                    flag=1;
                    break;
                }
            }
            if(flag==0){
                throw new Exception();
            }
            for (int i = 0; i < list.size(); i++) {
                for (int j = 0; j < list.get(i).object.size(); j++) {
                    String name = list.get(i).object.get(j).get_to();
                    if (name.equals(name1)) {
                        list.get(i).object.get(j).set_x(i1);
                        list.get(i).object.get(j).set_y(j1);
                        break;
                    }
                }
            }
            clear_all();
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void add_edge(ActionEvent e){
        try {
            String from1 = from.getText();
            String to1 = to.getText();
            String x1 = weight.getText();
            if(from1.length()==0||to1.length()==0||x1.length()==0)
                throw new Exception();
            from.clear();
            to.clear();
            weight.clear();
            int flag=0;
            int i1 = Integer.parseInt(x1);
            for (int i = 0; i < list.size(); i++) {
                String name = list.get(i).get_name();
                if (name.equals(from1)) {
                    flag=list.get(i).add_edge(to1, i1, list);
                    if(flag==0)
                        break;
                    output.setText("Edge added between " + from1 + " and " + to1);
                    break;
                }
            }
            if(flag==0)
                throw new Exception();
            clear_all();
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void search_edge(ActionEvent e){
        try {
            String from1 = from2.getText();
            String to1 = to2.getText();
            if(from1.length()==0||to1.length()==0)
                throw new Exception();
            from2.clear();
            to2.clear();
            int flag=0;
            for (int i = 0; i < list.size(); i++) {
                String name = list.get(i).get_name();
                if (name.equals(from1)) {
                    for (int j = 0; j < list.get(i).object.size(); j++) {
                        String to = list.get(i).object.get(j).get_to();
                        if (to.equals(to1)) {
                            output.setText("Vertex " + from1 + " at " + Integer.toString(list.get(i).get_y()) + "," + Integer.toString(list.get(i).get_x()) + "\r\n" + "Vertex " + to1 + " at " + Integer.toString(list.get(i).object.get(j).get_y()) + "," + Integer.toString(list.get(i).object.get(j).get_x()) + "\n" + "Weight is: " + Integer.toString(list.get(i).object.get(j).w));
                            flag=1;
                            break;
                        }
                    }
                    break;
                }
            }
            if(flag==0)
                throw new Exception();
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void delete_edge(ActionEvent e){
        try {
            String from1 = from3.getText();
            String to1 = to3.getText();
            if(from1.length()==0||to1.length()==0)
                throw new Exception();
            from3.clear();
            to3.clear();
            int flag=0;
            for (int i = 0; i < list.size(); i++) {
                String name = list.get(i).get_name();
                if (name.equals(from1)) {
                    for (int j = 0; j < list.get(i).object.size(); j++) {
                        String to = list.get(i).object.get(j).get_to();
                        if (to.equals(to1)) {
                            list.get(i).object.remove(j);
                            output.setText("Edge deleted successfully between " + from1 + " " + to1);
                            flag=1;
                            break;
                        }
                    }
                    break;
                }
            }
            if(flag==0)
                throw new Exception();
            clear_all();
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void modify_edge(ActionEvent e){
        try {
            String from1 = from4.getText();
            String to1 = to4.getText();
            String x1 = new_w.getText();
            if(from1.length()==0||to1.length()==0||x1.length()==0)
                throw new Exception();
            from4.clear();
            to4.clear();
            new_w.clear();
            int flag=0;
            int i1 = Integer.parseInt(x1);
            for (int i = 0; i < list.size(); i++) {
                String name = list.get(i).get_name();
                if (name.equals(from1)) {
                    for (int j = 0; j < list.get(i).object.size(); j++) {
                        String to = list.get(i).object.get(j).get_to();
                        if (to.equals(to1)) {
                            list.get(i).object.get(j).set_w(i1);
                            output.setText("Edge changed successfully between " + from1 + " " + to1);
                            flag=1;
                            break;
                        }
                    }
                    break;
                }
            }
            if(flag==0)
                throw new Exception();
            clear_all();
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
//        gridPaneMain.setRowIndex(gridPane,0);
//        gridPaneMain.setColumnIndex(gridPane,1);
//        gridPane.setMinSize(400,400);
//        gridPaneMain.getChildren().add(gridPane);
    }

    public void input(ActionEvent e) throws FileNotFoundException,IOException {
        try {
            String inp = file_txt.getText();
            if(inp.length()==0)
                throw new Exception();
            file_txt.clear();
            BufferedReader bufferedReader = new BufferedReader(new FileReader(inp));
            String string;
            string = bufferedReader.readLine();
            int i = Integer.parseInt(string);
            for (int j = 0; j < i; j++) {
                string = bufferedReader.readLine();
                String[] arrOfStr = string.split(" ", 3);
                name.setText(arrOfStr[0]);
                x_coord.setText(arrOfStr[1]);
                y_coord.setText(arrOfStr[2]);
                add.fire();
            }
            string = bufferedReader.readLine();
            i = Integer.parseInt(string);
            for (int j = 0; j < i; j++) {
                string = bufferedReader.readLine();
                String[] arrOfStr = string.split(" ", 3);
                from.setText(arrOfStr[0]);
                to.setText(arrOfStr[1]);
                weight.setText(arrOfStr[2]);
                add_edge.fire();
            }
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void output1(ActionEvent e)throws FileNotFoundException{
        try {
            String out = fileout_txt.getText();
            if(out.length()==0)
                throw new Exception();
            fileout_txt.clear();
            File file = new File(out + "/output.txt");
            System.setOut(new PrintStream(file));
            System.out.println(list.size());
            Collections.sort(list, new Compare1());
            int x = 0;
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i).get_name() + " " + list.get(i).get_y() + " " + list.get(i).get_x());
                x += list.get(i).object.size();
            }
            for (int i = 0; i < list.size(); i++) {
                list.get(i).sort();
            }
            System.out.println(x);
            for (int i = 0; i < list.size(); i++) {
                for (int j = 0; j < list.get(i).object.size(); j++) {
                    System.out.println(list.get(i).get_name() + " " + list.get(i).object.get(j).get_to() + " " + list.get(i).object.get(j).get_w());
                }
            }
            output.setText("Exported Successfully");
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void djk(ActionEvent e){
        //clear_all();
        try {
            String from1 = from5.getText();
            String to1 = to5.getText();
            String type1 = type.getText();
            if(from1.length()==0||to1.length()==0||type1.length()==0)
                throw new Exception();
            from5.clear();to5.clear();type.clear();
            Map<String, Integer> spt = new HashMap<String, Integer>();
            Map<String, Integer> level = new HashMap<String, Integer>();
            Map<String, String> par = new HashMap<String, String>();
            int flag1=0,flag2=0;
            for (int i = 0; i < list.size(); i++) {
                String name = list.get(i).get_name();
                spt.put(name, 0);
                level.put(name, 100000);
                par.put(name, "");
                if(name.equals(from1))
                    flag1=1;
                if(name.equals(to1))
                    flag2=1;
            }
            if(flag1==0 || flag2==0)
                throw new Exception();
            level.put(from1, 0);
            par.put(from1, from1);
            for (int i = 0; i < list.size(); i++) {
                int mn = 100000;
                int min_ind = -1;
                for (int j = 0; j < list.size(); j++) {
                    String name = list.get(j).get_name();
                    if (spt.get(name) == 0 && level.get(name) < mn) {
                        mn = level.get(name);
                        min_ind = j;
                    }
                }
                if (min_ind == -1)
                    break;
                String str = list.get(min_ind).get_name();
                spt.put(str, 1);
                if (str.equals(to1))
                    break;
                for (int j = 0; j < list.get(min_ind).object.size(); j++) {
                    String name = list.get(min_ind).object.get(j).get_to();
                    int w = list.get(min_ind).object.get(j).get_w();
                    if (spt.get(name) == 0 && level.get(str) + w < level.get(name)) {
                        par.put(name, str);
                        level.put(name, level.get(str) + w);
                    }
                }
            }
            ArrayList<Pair<Integer, Integer>> position = new ArrayList<Pair<Integer, Integer>>();
            if (par.get(to1).equals("")) {
                output.setText("No path found" + from1 + " " + to1);
                return;
            } else if (from1.equals(to1)) {
                output.setText(from1 + " -> " + to1);
                return;
            } else {
                ArrayList<String> ans = new ArrayList<String>();
                ans.add(to1);
                for (int i = 0; i < list.size(); i++) {
                    if (to1.equals(list.get(i).get_name())) {
                        position.add(new Pair<Integer, Integer>(list.get(i).get_x(), list.get(i).get_y()));
                        break;
                    }
                }
                while (!par.get(to1).equals(from1)) {
                    String str = par.get(to1);
                    for (int i = 0; i < list.size(); i++) {
                        if (str.equals(list.get(i).get_name())) {
                            position.add(new Pair<Integer, Integer>(list.get(i).get_x(), list.get(i).get_y()));
                            break;
                        }
                    }
                    ans.add(str);
                    to1 = str;
                }
                for (int i = 0; i < list.size(); i++) {
                    if (from1.equals(list.get(i).get_name())) {
                        position.add(new Pair<Integer, Integer>(list.get(i).get_x(), list.get(i).get_y()));
                        break;
                    }
                }
                output.setWrapText(true);
                String result = "";
                result = result.concat(from1);
                for (int i = ans.size() - 1; i >= 0; i--) {
                    result = result.concat(" -> " + ans.get(i));
                }
                output.setText(result);
            }
            type1 = type1.toLowerCase();
            PathTransition pathTransition = new PathTransition();
            PathTransition pathTransition1 = new PathTransition();
            if (type1.equals("line")) {
                for (int i = position.size() - 1; i >= 1; i--) {
                    int a = position.get(i).getKey();
                    int b = position.get(i).getValue();
                    int c = position.get(i - 1).getKey();
                    int d = position.get(i - 1).getValue();
                    Line line = new Line();
                    line.setStartX(a *gl + 10);
                    line.setStartY(b *gl + 10);
                    line.setEndX(c *gl + 10);
                    line.setEndY(d *gl + 10);
                    line.setStroke(Color.GREENYELLOW);
                    line.setStrokeWidth(10);
                    root.getChildren().add(line);
                }
                return;
            } else if (type1.equals("circle")) {
                Circle circle = new Circle();
                circle.setCenterX(1);
                circle.setCenterY(1);
                circle.setRadius(15);
                circle.setFill(Color.BROWN);
                circle.setStrokeWidth(20);
                root.getChildren().add(circle);
                pathTransition.setNode(circle);
            } else if (type1.equals("square")) {
                Rectangle rectangle = new Rectangle(300, 135, 30, 30);
                rectangle.setFill(Color.HOTPINK);
                root.getChildren().add(rectangle);
                pathTransition.setNode(rectangle);
            } else if (type1.equals("triangle")) {
                Polygon polygon = new Polygon();
                polygon.getPoints().addAll(new Double[]{
                        0.0, 0.0,
                        50.0, 10.0,
                        10.0, 50.0});
                polygon.setFill(Color.HOTPINK);
                root.getChildren().add(polygon);
                pathTransition.setNode(polygon);
            } else if (type1.equals("plus")) {
                Line line = new Line();
                line.setStartX(1);
                line.setStartY(1);
                line.setEndX(1);
                line.setEndY(30);
                line.setStroke(Color.ORANGE);
                line.setStrokeWidth(5);
                root.getChildren().add(line);
                pathTransition.setNode(line);

                Line line1 = new Line();
                line1.setStartX(1);
                line1.setStartY(1);
                line1.setEndX(30);
                line1.setEndY(1);
                line1.setStroke(Color.ORANGE);
                line1.setStrokeWidth(5);
                root.getChildren().add(line1);
                pathTransition1.setNode(line1);
            } else if (type1.equals("cross")) {
                Line line = new Line();
                line.setStartX(1);
                line.setStartY(1);
                line.setEndX(30);
                line.setEndY(30);
                line.setStroke(Color.ORANGE);
                line.setStrokeWidth(5);
                root.getChildren().add(line);
                pathTransition.setNode(line);

                Line line1 = new Line();
                line1.setStartX(30);
                line1.setStartY(1);
                line1.setEndX(1);
                line1.setEndY(30);
                line1.setStroke(Color.ORANGE);
                line1.setStrokeWidth(5);
                root.getChildren().add(line1);
                pathTransition1.setNode(line1);
            }
            else
                throw new Exception();
            Path path = new Path();
            MoveTo moveTo = new MoveTo(position.get(position.size() - 1).getKey() * gl + 10, position.get(position.size() - 1).getValue() * gl + 10);
            path.getElements().add(moveTo);
            for (int i = position.size() - 2; i >= 0; i--) {
                int a = position.get(i).getKey()*gl  + 10;
                int b = position.get(i).getValue() *gl + 10;
                CubicCurveTo cubicCurveTo = new CubicCurveTo(a, b, a, b, a, b);
                path.getElements().add(cubicCurveTo);
            }

            pathTransition.setDuration(Duration.seconds(position.size() - 1));
            pathTransition.setPath(path);
            pathTransition.setCycleCount(1000);
            pathTransition.setAutoReverse(false);

            pathTransition1.setDuration(Duration.seconds(position.size() - 1));
            pathTransition1.setPath(path);
            pathTransition1.setCycleCount(1000);
            pathTransition1.setAutoReverse(false);
            pathTransition.play();
            pathTransition1.play();
        }
        catch (Exception a){
            Alert sh = new Alert(Alert.AlertType.ERROR);
            sh.setContentText("Please Input Correct Details");
            sh.setHeaderText("Something Gone Wrong");
            sh.showAndWait();
        }
    }
    public void add_on_click(MouseEvent e){
        if(!e.isShiftDown() && !e.isControlDown() && vertex_mode.isSelected() && !e.isAltDown()){
            double x=e.getX();
            double y=e.getY();
            TextInputDialog dialog = new TextInputDialog("Enter name of vertex to be added");
            dialog.showAndWait();
            String str = dialog.getEditor().getText();
//            System.out.println(str + " " + x + " " + y);
            int x1 = (int)(x-10)/gl;
            int y1 = (int)(y-10)/gl;
            name.setText(str);
            x_coord.setText(Integer.toString(y1));
            y_coord.setText(Integer.toString(x1));
            add.fire();
        }
    }
    int t=0;
    ArrayList<String> arr = new ArrayList<String>();
    public void clear_all(){
        root.getChildren().clear();
        for(int i1=0;i1<list.size();i1++){
            String name1=list.get(i1).get_name();
            int i=list.get(i1).get_x();
            int j=list.get(i1).get_y();
            Circle circle;
            circle = new Circle((double)(i*gl+10), (double)(j*gl+10), 25, Color.BLUE);
            Text text = new Text((double)(i*gl),(double)(j*gl+10),name1);
            text.setFont(new Font(24));
            text.setFill(Color.WHITE);
            circle.setStroke(Color.PEACHPUFF);
            circle.setStrokeWidth(4);
            root.getChildren().add(circle);
            root.getChildren().add(text);
            circle.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    if(mouseEvent.isShiftDown() && vertex_mode.isSelected() && !mouseEvent.isControlDown()){
                        name3.setText(name1);
//                        System.out.println("hello");
                        delete.fire();
                    }
                }
            });
            circle.setOnMousePressed(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    if(mouseEvent.isControlDown()&& edge_mode.isSelected() && !mouseEvent.isShiftDown()) {
                        t++;
                        if (t % 2 == 1) {
                            arr.clear();
                            arr.add(name1);
                            circle.setFill(Color.YELLOW);
                        } else {
                            circle.setFill(Color.YELLOW);
                            String str = arr.get(0);
                            TextInputDialog dialog = new TextInputDialog("Enter weight to be added");
                            dialog.showAndWait();
                            String w = dialog.getEditor().getText();
                            from.setText(str);
                            to.setText(name1);
                            weight.setText(w);
                            add_edge.fire();
                        }
                    }
                }
            });
        }
        for(int i=0;i<list.size();i++){
            int a=list.get(i).get_x();
            int b=list.get(i).get_y();
            for(int j=0;j<list.get(i).object.size();j++){
                int k=i;
                int l=j;
                int c=list.get(i).object.get(j).get_x();
                int d=list.get(i).object.get(j).get_y();
                Line line = new Line();
                line.setStartX(a*gl+10);
                line.setStartY(b*gl+10);
                line.setEndX(c*gl+10);
                line.setEndY(d*gl+10);
                line.setStroke(Color.WHITE);
                line.setStrokeWidth(4);
                double t1 = (a+c)/2;
                double t2  = (b+d)/2;
                Text text = new Text((double)(t1*gl),(double)(t2*gl+25),Integer.toString(list.get(i).object.get(j).get_w()));
                text.setFont(new Font(18));
                text.setFill(Color.WHITE);
                root.getChildren().add(text);
                root.getChildren().add(line);
                line.setOnMousePressed(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        if(!mouseEvent.isControlDown()&& edge_mode.isSelected() && mouseEvent.isShiftDown()){
                            from3.setText(list.get(k).get_name());
                            to3.setText(list.get(k).object.get(l).get_to());
//                        System.out.println("hello");
                            delete_v.fire();
                        }
                    }
                });
            }
        }
    }
}
class Compare1 implements Comparator<Edges>{
    public int compare(Edges a, Edges b){
        return a.get_name().compareTo(b.get_name());
    }
}
class Compare2 implements  Comparator<MyClass>{
    public int compare(MyClass a, MyClass b){
        return a.get_to().compareTo(b.get_to());
    }
}